# AlgoTrade · INDstocks local trading workspace

React UI and .NET 10 API for a Windows laptop. **Current release: manual paper simulation and read-only INDstocks REST access.** This is a working foundation, not the completed automated/live platform in the handoff. No real orders can be submitted. See [implementation status](docs/IMPLEMENTATION_STATUS.md) before using it.

![Paper dashboard with synthetic positions](docs/screenshots/dashboard.png)

## Put it in C:\RJ\AlgoTrade

The development copy was created in a cloud workspace at `/workspace/AlgoTrade`. That is not your laptop's C: drive. Download `AlgoTrade-source.zip` and extract it:

```powershell
New-Item -ItemType Directory -Force C:\RJ | Out-Null
Expand-Archive -Path "$HOME\Downloads\AlgoTrade-source.zip" -DestinationPath C:\RJ
Set-Location C:\RJ\AlgoTrade
```

The archive contains the `AlgoTrade` directory, with separate `ui` and `api` folders. It excludes credentials, databases, logs and installed dependencies. If you already have an `AlgoTrade` directory, choose another destination or back it up before extracting; do not overwrite local configuration.

Once a GitHub repository exists, the equivalent fresh-clone command is:

```powershell
git clone <your-repository-url> C:\RJ\AlgoTrade
Set-Location C:\RJ\AlgoTrade
```

No remote repository has been created or pushed yet.

## First run on Windows (no Docker)

Requirements: Windows 10/11, PowerShell 5.1 or 7, .NET **10 SDK**, Node.js **24 LTS** (minimum 22.12), npm, internet for initial package restore; Git only for cloning. Allow roughly 2 GB for SDK/dependencies/browser tests. No Python, database server, IIS, Visual Studio, SMTP, paid news account or Docker is needed for paper simulation.

Open PowerShell in the project folder:

```powershell
Set-Location C:\RJ\AlgoTrade
# Needed only if local policy blocks downloaded scripts; applies to this terminal only.
Set-ExecutionPolicy -Scope Process -ExecutionPolicy RemoteSigned
# If Windows marked your extracted files as downloaded, unblock only this project's scripts.
Get-ChildItem .\scripts\*.ps1 | Unblock-File
.\scripts\setup-windows.ps1 -InstallPrerequisites
.\scripts\run-dev.ps1
```

`-InstallPrerequisites` uses Microsoft's winget catalog to install missing .NET 10 SDK and Node.js LTS. It may require Windows elevation. If both are already installed, omit that switch. If winget is unavailable, install from [Microsoft .NET 10](https://dotnet.microsoft.com/download/dotnet/10.0) and [Node.js](https://nodejs.org/en/download), reopen PowerShell, then run setup without the switch.

Setup checks versions, restores pinned NuGet/npm dependencies, builds UI/API, creates local environment files, generates **different random operator passwords** for DEV and PROD, and applies committed EF Core SQLite migrations to both databases. Existing environment files are never overwritten. Database creation/migration requires no broker account.

Open **http://127.0.0.1:5173** (the script opens it automatically). Sign in using the `LOCAL_ADMIN_PASSWORD` value in `api/.env.development`. Open that file in your editor; do not share or commit it. Start a paper session with the exact confirmation **START PAPER**. Use Orders to buy/sell the synthetic `DEMO` instrument. Paper mode does not need a broker token. Do not interpret DEMO prices as market data.

## Configure credentials

| File / value | Required? | What to put there |
|---|---|---|
| `api/.env.development` → `LOCAL_ADMIN_PASSWORD` | Yes | Setup generates a unique random local login password. Replace with >=16 characters if desired. |
| `api/.env.production` → `LOCAL_ADMIN_PASSWORD` | Yes for PROD | Separate generated password; do not reuse DEV's password. |
| API file → `INDSTOCKS_ACCESS_TOKEN` | Only for read-only broker calls | Token generated through your official INDstocks account. Raw value, no `Bearer` prefix or quotes. Restart after changes. |
| API file → `INDSTOCKS_ALGO_ID` | No | Reserved; this release has no live execution adapter. Leave blank. |
| `ui/.env.development`, `ui/.env.production` | Created automatically | Public UI settings only. Keep `VITE_API_BASE=/api`. **Never put passwords or broker tokens here.** |
| Email / SMTP / client secret / news key | No | This release uses local operator login, with no email or SMTP service. |

Local files are copied from committed `*.example` templates. The root `.env.example` is an index, not a loaded configuration file. API values are literal: no surrounding quotes, variable expansion or inline comments. Process environment variables override environment-file values; ASP.NET user-secrets override files in DEV. Remove stale process variables when testing configuration changes. Do not place production credentials in development files or shared shell startup profiles.

Optional DEV token storage outside files:

```powershell
dotnet user-secrets set "INDSTOCKS_ACCESS_TOKEN" "<your-token>" --project .\api\TradingBot.Api
```

For production use a protected user-level secret delivery mechanism such as Windows Credential Manager via a separately configured launcher; **this repository does not yet include a Credential Manager reader**. Local environment files are plaintext and should be accessible only to your Windows user. Credentials never go into browser storage, database rows or Git. See [API setup](docs/API_SETUP.md).

## Start, stop, production and health

```powershell
.\scripts\run-dev.ps1                       # UI :5173, API :5100, trading-dev.db
.\scripts\health.ps1 -Environment Development
.\scripts\stop-bot.ps1 -Environment Development

.\scripts\run-prod.ps1                      # built UI + API :5101, trading-prod.db
.\scripts\health.ps1 -Environment Production
.\scripts\stop-bot.ps1 -Environment Production
.\scripts\stop-bot.ps1                      # stop both managed environments
```

PROD is a deployment environment, **not Live mode**. It defaults to Paper and this release rejects `TRADING_MODE=LIVE` at startup. PROD serves the built UI from the API; it does not run Vite. DEV and PROD use separate cookies, passwords and SQLite files. Always use `127.0.0.1` consistently. API binding is loopback only. Ports are fixed in this version; stop conflicting processes rather than exposing the app on your LAN.

**Emergency stop:** the red UI button immediately persists `EMERGENCY_STOPPED`, cancels simulated pending order remainders, and retains holdings. It is serialized with order submission and worker fills. It survives restart. Type START PAPER to reconcile and recover manually. It does not liquidate holdings. `stop-bot.ps1` stops processes; it is not a substitute for the persisted emergency stop. A previously running session always enters `RECOVERY_REQUIRED` after restart.

Runtime process records and logs live in `.runtime/`; SQLite databases live in `api/data/`. Scripts stop only processes they started, checking process creation time against the recorded PID. Do not delete process records while processes are running. Back up SQLite only while the API is stopped, including any WAL/SHM files if present; see troubleshooting.

Optional logon startup (monitoring only):

```powershell
.\scripts\register-startup.ps1 -Environment Production
# Remove later:
.\scripts\register-startup.ps1 -Environment Production -Remove
```

## Build and test

```powershell
.\scripts\test.ps1
```

This runs xUnit, TypeScript checks, Vitest and a production UI build. Tests use mocks/disposable SQLite and never place real orders. For browser tests, use a **disposable DEV database** (the test places simulated orders and emergency-stops it):

```powershell
.\scripts\run-dev.ps1
$env:E2E_PASSWORD = '<the disposable DEV operator password>'
.\scripts\test.ps1 -EndToEnd
Remove-Item Env:E2E_PASSWORD
```

Playwright installs Chromium only for the optional end-to-end tests. Unit/integration tests require no browser, Windows credentials or broker token. CI runs Linux and Windows build/test jobs with Paper mode only. Current recorded results and limitations are in [VALIDATION.md](docs/VALIDATION.md).

## Folders

```text
AlgoTrade/
  ui/                         React + TypeScript + Vite, Tailwind, local shadcn-style components, ECharts
  api/
    TradingBot.Domain/        entities and money/order models
    TradingBot.Application/   contracts, risk rules, fee estimates, deterministic backtest
    TradingBot.Infrastructure/ EF Core migrations, SQLite ledger, read-only broker adapter
    TradingBot.Api/           authentication, CSRF, REST, SignalR, static production hosting
    TradingBot.Worker/        simulated partial-fill worker
    TradingBot.sln
  tests/UnitTests/
  tests/IntegrationTests/
  ui/tests/                   Playwright browser flows
  scripts/                    Windows setup/start/stop/test/health/startup
  docs/                       setup, architecture, status, broker references and strategy limits
  .github/workflows/ci.yml
```

The worker runs inside the API host, so there is one order gate and one owner per database. Do not run multiple independent hosts against the same file.

## What works, and what remains

Working: local sign-in and CSRF protection; responsive navigation; paper dashboard, orders, positions, trades and audit events; persisted stop/recovery; idempotent order IDs; partial fills, conservative slippage and indicative charges; capital/position/loss-budget checks; deterministic SMA backtesting from uploaded candles; read-only REST methods for profile/funds/holdings/positions/quotes/candles/instrument CSV; SignalR dashboard refresh; DEV/PROD isolation; migrations; scripts; tests; CI configuration.

Unavailable: real-time broker WebSockets; real-symbol paper execution and continuous live valuation; ranked TradeList/screening; news/earnings provider; verified exchange calendar; automatic entry/exit strategies; production broker reconciliation; real order placement/modification/cancellation; Live activation. The corresponding UI sections state this explicitly. No placeholder news or invented candidates are displayed. Setting a token does **not** implement these features. Read-only broker methods have contract/mock tests, but a valid customer token has not been supplied, so connectivity is not verified against an account.

Before Live: implement and test the missing broker execution/reconciliation lifecycle, uncertainty handling and compliance controls; verify broker/exchange permission and whitelisted static IPv4; validate tariff, calendar, instrument IDs, fresh feeds and overnight policies; complete failure/restart tests; conduct paper sessions; then add a separate authenticated backend activation and obtain explicit user authorization. **A token alone can never enable Live in this release.** See [status and acceptance checklist](docs/IMPLEMENTATION_STATUS.md).

## More documentation

- [Windows setup](docs/WINDOWS_SETUP.md)
- [INDstocks API setup and verified sources](docs/API_SETUP.md)
- [Architecture and data ownership](docs/ARCHITECTURE.md)
- [Strategy and backtesting format](docs/TRADING_STRATEGY.md)
- [Risk management and indicative costs](docs/RISK_MANAGEMENT.md)
- [Troubleshooting](docs/TROUBLESHOOTING.md)
- [Original handoff](docs/HANDOFF.md)

## Push to GitHub later

A local repository is prepared; no GitHub push was requested for this step. After creating a **private empty repository**, run:

```powershell
git init -b main                      # only if this copy has no .git directory
git add .
git status --short                    # confirm no secrets, DBs, logs or personal data
git commit -m "Initial local paper trading workspace"
git remote add origin https://github.com/<owner>/<private-repository>.git
git push -u origin main
```

MIT applies to original project code. Dependencies retain their own licenses. The official broker documentation export/specification under `docs/broker` belongs to its publisher and is supplied as an integration reference, not relicensed by this project.
