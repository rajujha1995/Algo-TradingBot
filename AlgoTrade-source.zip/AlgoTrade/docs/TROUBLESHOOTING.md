# Troubleshooting

| Symptom | Remedy |
|---|---|
| `dotnet` not found / no SDK 10 | Run setup with -InstallPrerequisites or install .NET 10 SDK (not runtime only), then reopen PowerShell. |
| npm/Node missing or too old | Install Node 24 LTS. Run `node --version`, `npm --version`. Minimum Node 22.12. |
| winget missing | Install prerequisites from official download pages in README, reopen PowerShell, run setup without install switch. |
| Scripts blocked | Use README's process-scoped RemoteSigned command and unblock only the downloaded scripts. Organization-enforced policy may require your administrator. |
| Restore/TLS errors | Check internet/proxy access to NuGet/npm. Do not turn off certificate validation. Setup exits on the first failed external command. |
| Password placeholder / invalid startup config | Run setup or replace LOCAL_ADMIN_PASSWORD in the relevant API file (>=16 characters). Confirm APP_ENV matches ASPNETCORE_ENVIRONMENT. |
| Wrong login password | DEV uses api/.env.development; PROD uses api/.env.production. Check user-secrets or process environment overrides. Passwords are intentionally different. |
| HTTP 429 at login | Five attempts per minute: wait one minute and retry. |
| Login/CSRF HTTP 403 | Use the same host consistently (127.0.0.1), reload/sign in to refresh the token. Do not reuse a pre-login CSRF token after signing in. |
| API healthy, trading not ready | /healthz means the server started; authenticated System Health lists missing trading prerequisites. Live remains disabled. |
| Port 5100, 5101 or 5173 in use | Stop the previously managed environment with scripts/stop-bot.ps1. Inspect unrelated listeners before stopping them; scripts will not kill unrelated processes. |
| Process record remains but no process | stop-bot.ps1 removes a stale record after verifying the recorded PID is absent. If the PID was reused, inspect before manually deleting the record. |
| Database locked | Do not run two API hosts against the same environment. Stop the owning process; do not delete the .lock file to bypass ownership. |
| Migration interrupted | Stop the API and back up the DB/WAL/SHM. EF SQLite may leave __EFMigrationsLock after a crash; follow EF's documented recovery procedure after confirming no host is using the file. Do not delete ledger data. |
| BROKER token missing/expired/forbidden | Replace backend token via official account flow and restart. Paper simulation requires no token. Error responses are sanitized. |
| Live mode cannot start | Expected: live execution/compliance is not implemented. Keep TRADING_MODE=PAPER and AUTO_TRADING_ENABLED=false. |
| TradeList/news empty | Those services are unimplemented; adding credentials alone does not enable them. See IMPLEMENTATION_STATUS.md. |
| Backtest rejected | Use a JSON array, at least seven ordered UTC candles, valid OHLC ranges, positive prices and nonnegative volume. Use the synthetic example to verify upload. |
| Paper BUY rejected | Start PAPER first; verify cash including fees, one-position rule, pending orders, capital and loss budget. |
| Paper SELL rejected | No shorting; only sell held quantity, without another pending remainder, and with proceeds exceeding estimated charges. |
| Browser test fails on repeat run | E2E requires a disposable DEV database with no previous open position. Stop DEV, back up/move its entire data directory, rerun setup, restart and test with its existing operator password. Never delete a personal/live ledger. |
| Database/log backup | Stop the environment first, copy api/data/trading-*.db and any -wal/-shm companions, plus local config separately into a protected backup. Do not commit/upload backups. |

Runtime logs: `.runtime/api-dev.*.log`, `.runtime/api-prod.*.log`, `.runtime/frontend-dev.*.log`. Audit events are available in System Logs. Don't paste tokens or personal brokerage payloads into issues. API shutdown after a running session always requires manual recovery; emergency stop is preserved across restart.
