# CODEX HANDOFF: INDstocks Automated Trading Platform

## 1. Role and Objective

Act as a Principal Software Architect, Senior .NET Engineer, React Engineer, Quantitative Trading Systems Developer, and Security Engineer.

Build a production-quality, locally hosted automated equity trading application using **INDstocks Flash API v1**.

The application will run on a dedicated Windows laptop and eventually trade Indian NSE/BSE equities automatically.

**Primary objective:** Build a reliable, secure, testable trading platform. Do not optimize for guaranteed profits or assume any strategy will be profitable.

### Technology stack

- Frontend: React, TypeScript, Vite
- UI components: shadcn/ui
- Styling: Tailwind CSS
- Charts: TradingView Lightweight Charts or Apache ECharts
- Backend: ASP.NET Core Web API, .NET 10 LTS
- Architecture: Clean Architecture with SOLID principles
- ORM: Entity Framework Core
- Database: SQLite
- Real-time communication: SignalR
- Background processing: .NET BackgroundService
- Logging: Serilog
- Testing: xUnit, Vitest, Playwright
- API documentation: OpenAPI/Swagger
- Deployment: Windows localhost
- Source control: GitHub
- External broker: INDstocks Flash API v1

Prefer stable, maintained, free and open-source dependencies.

## 2. Official Broker Documentation

Use these authoritative sources:

- https://api-docs.indstocks.com/
- https://api-docs.indstocks.com/llms/
- https://api-docs.indstocks.com/Users/
- https://api-docs.indstocks.com/MarketQuote/
- https://api-docs.indstocks.com/Websockets/
- https://www.indstocks.com/features/api-trading

**Mandatory:** Download and inspect the official LLM Markdown export and OpenAPI specification before implementing the broker adapter.

Do not invent endpoints, response structures, authentication requirements, WebSocket messages or trading capabilities.

Verify supported operations against the official documentation. If something cannot be verified, implement an interface with a disabled feature and document the missing dependency.

Never use undocumented private INDmoney endpoints, browser session extraction, scraping or hardcoded credentials.

## 3. Solution Structure

Create the following solution:

```text
indstocks-trading-bot/
│
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   ├── pages/
│   │   ├── hooks/
│   │   ├── services/
│   │   ├── stores/
│   │   ├── types/
│   │   └── styles/
│   ├── .env.development.example
│   ├── .env.production.example
│   └── package.json
│
├── backend/
│   ├── TradingBot.Domain/
│   ├── TradingBot.Application/
│   ├── TradingBot.Infrastructure/
│   ├── TradingBot.Api/
│   ├── TradingBot.Worker/
│   └── TradingBot.sln
│
├── tests/
│   ├── UnitTests/
│   ├── IntegrationTests/
│   └── EndToEndTests/
│
├── scripts/
│   ├── setup-windows.ps1
│   ├── run-dev.ps1
│   ├── run-prod.ps1
│   └── stop-bot.ps1
│
├── docs/
│   ├── ARCHITECTURE.md
│   ├── API_SETUP.md
│   ├── WINDOWS_SETUP.md
│   ├── TRADING_STRATEGY.md
│   ├── RISK_MANAGEMENT.md
│   └── TROUBLESHOOTING.md
│
├── .gitignore
├── README.md
└── .env.example
```

### Clean Architecture

**Domain**
- Stock, Instrument, Trade, Order, Position
- TradeCandidate, TradingSignal, PortfolioSnapshot
- TradingStrategy, RiskRule, TradingSession
- ProfitLoss, MarketNews, EarningsEvent

**Application**
- Interfaces, commands, queries and handlers
- Trading orchestration
- Risk evaluation
- Stock screening
- Profit/loss calculations
- Broker reconciliation

**Infrastructure**
- INDstocks REST and WebSocket adapters
- EF Core SQLite persistence
- News providers
- Market calendar
- Configuration and logging

**API**
- REST controllers
- SignalR hubs
- Authentication and authorization
- Health endpoints

**Worker**
- Market monitoring
- Stock screening
- Order lifecycle
- Position monitoring
- Risk enforcement
- End-of-day processing

Enforce dependency direction. Domain and Application must not depend on Infrastructure.

## 4. Environment Configuration

Implement two deployment environments:

**DEV**
- Uses development configuration.
- Uses a separate SQLite database.
- Defaults to simulated orders.
- May use authenticated read-only broker data.
- Must never submit real orders.

**PROD**
- Uses production configuration.
- Uses a separate database.
- Supports Paper and Live trading modes.
- Defaults to Paper mode on first installation.
- Live mode requires explicit activation and safety checks.

Use:

```text
backend/.env.development
backend/.env.production

frontend/.env.development
frontend/.env.production
```

Create example files containing placeholders only.

Sample backend configuration:

```dotenv
APP_ENV=Development
TRADING_MODE=PAPER

INDSTOCKS_BASE_URL=https://api.indstocks.com
INDSTOCKS_ACCESS_TOKEN=
INDSTOCKS_ALGO_ID=

TRADING_CAPITAL_LIMIT=1000
MAX_OPEN_POSITIONS=1
MAX_DAILY_PLANNED_LOSS=50
MAX_TOTAL_PLANNED_LOSS=100

MARKET_TIMEZONE=Asia/Kolkata
ENTRY_START=09:30
ENTRY_END=11:00
EXIT_REVIEW_TIME=15:15

AUTO_TRADING_ENABLED=false
ALLOW_OVERNIGHT_HOLDINGS=true

DATABASE_PATH=./data/trading-dev.db
```

The example values are starting assumptions, not proven optimal strategy parameters.

### Environment security

- Never expose broker tokens to React.
- Never store tokens in localStorage.
- Backend only communicates with INDstocks.
- Prefer Windows Credential Manager or protected user-level secrets for live credentials.
- Never commit actual `.env` files.
- Validate all configuration values at startup.
- Display the active environment prominently.
- Environment changes require a controlled restart.
- Never permit changing to Live trading by simply editing frontend state.
- Production Live activation must require explicit confirmation and a separate backend authorization step.
- No production secrets in development.
- Bind the local API to loopback by default.
- Use appropriate authentication and CSRF protection for state-changing operations.

## 5. Dashboard

Build a responsive trading dashboard.

The user will refine the visual design later. Create clean, reusable components without coupling business logic to presentation.

### Dashboard KPIs

Display:

1. Invested Amount
2. Current Portfolio Value
3. Unrealized P&L (₹)
4. Unrealized P&L (%)
5. Realized P&L (₹)
6. Today's Net P&L
7. Available Cash
8. Total Charges
9. Open Positions
10. Active Orders

Example:

```text
Invested Amount:      ₹1,000
Current Market Value: ₹1,025
Unrealized P&L:       +₹25
Unrealized P&L:       +2.50%
```

The example is illustrative only.

Distinguish invested cost basis from total account value. Portfolio totals must include cash and must not double-count holdings or pending orders.

Display brokerage, statutory charges, taxes, and net realized returns separately.

### Additional dashboard components

- Live market status
- Trading engine status
- Broker connection status
- Current environment
- Paper/Live indicator
- Latest trade
- Pending orders
- Daily performance chart
- Emergency Stop
- Last successful broker synchronization
- Data freshness and market-feed status

Update market values through SignalR.

Never display simulated prices as live prices.

## 6. Emergency Stop

Implement a prominent red **EMERGENCY STOP** button in the application header.

This is a critical safety feature.

When clicked:

1. Immediately disable new strategy-generated orders.
2. Persist the stopped state in the database.
3. Prevent all background workers from creating new trades.
4. Cancel outstanding unfilled orders when broker connectivity permits.
5. Stop automatic entry and normal exit strategies.
6. Display all existing holdings and their risk exposure.
7. Notify the user of any orders that could not be cancelled.
8. Require manual confirmation before restarting trading.

The stop must be enforced by the backend, not just React.

Use a persistent, centralized trading state checked immediately before every order submission.

Support these states:

```text
STOPPED
PAPER_RUNNING
LIVE_RUNNING
EMERGENCY_STOPPED
RECOVERY_REQUIRED
```

Emergency Stop must be idempotent and survive application restarts.

**Important:** Emergency Stop does not automatically liquidate holdings. Implement a separate, explicitly confirmed emergency liquidation action if broker capabilities permit.

The interface must never claim all trading has stopped until broker order states have been reconciled.

## 7. Daily TradeList

Create a dedicated page named **TradeList**.

### Objective

Generate a ranked list of 10 Indian stocks worth monitoring for the current trading session.

The TradeList is a candidate list, not an instruction to buy all 10.

Target composition:

- 4 large-cap stocks
- 3 mid-cap stocks
- 3 small-cap stocks

Use an authoritative, maintained source for market-cap classification. If reliable classification data is unavailable, label the classification unverified rather than guessing.

### TradeList fields

| Field | Description |
|---|---|
| Rank | 1–10 |
| Symbol | NSE/BSE symbol |
| Company | Company name |
| Category | Large/Mid/Small |
| Previous Close | Prior closing price |
| Pre-open Price | Verified auction data |
| Gap % | Opening gap |
| Volume | Latest available volume |
| RSI | Technical indicator |
| VWAP | Volume-weighted price |
| Trend | Bullish/Neutral/Bearish |
| Score | Strategy ranking score |
| Signal | Watch/Buy/Reject |
| Reason | Explanation for selection |

### Screening logic

Evaluate:

- Previous day's trend
- Pre-open price indication, if officially available
- Opening gap
- Relative trading volume
- Liquidity
- Bid/ask spread
- First 5-minute candle
- First 15-minute candle
- VWAP relationship
- RSI
- EMA 9/20
- ATR volatility
- Recent earnings and market news
- Market-wide trend
- Trading costs

Do not assume that positive pre-open returns predict positive closing returns.

Pre-open data must be verified separately from ordinary real-time quote availability.

If pre-open auction data is unavailable, use a clearly labeled opening-session strategy instead.

### TradeList lifecycle

```text
08:55 - Begin pre-open analysis
09:08 - Freeze preliminary candidates
09:15 - Start monitoring regular market
09:30 - Recalculate ranking
09:30–11:00 - Evaluate entry signals
15:15 - Review positions and exits
15:30 - End regular session
```

Use an exchange calendar and respect holidays, special sessions and market schedule changes.

Store every daily TradeList for historical analysis.

## 8. Trading Strategy

Initial capital: ₹1,000.

Initial trial: five trading sessions.

Trading segment: NSE/BSE equity delivery.

No derivatives, leverage, short selling or margin trading.

Maximum simultaneous positions: one.

The ₹1,000 capital limit must include pending commitments and estimated transaction costs.

### Entry conditions

Buy only when:

- The exchange is open.
- The stock is on the approved TradeList.
- The stock meets the configured liquidity requirements.
- Market data is fresh.
- Technical entry conditions pass.
- Available funds are sufficient.
- Estimated costs are acceptable.
- Risk checks pass.
- There is no conflicting open or pending order.
- Trading is enabled.
- Broker permissions and compliance checks pass.

Do not force a trade every day.

### Exit conditions

Evaluate positions continuously.

Exit when:

- A validated net-profit target is reached.
- A configured risk stop is triggered.
- A strategy invalidation condition occurs.
- A position exceeds configured holding limits.
- An explicit authorized liquidation command is received.

At 3:15 PM, review all open positions.

Profitable positions may be closed if expected proceeds exceed costs and satisfy the configured profit rule.

Losing positions may be held overnight only when the overnight-risk policy allows it.

Do not hold indefinitely merely to avoid realizing a loss.

Use conservative execution assumptions and handle partial fills.

## 9. Risk Management

Implement mandatory pre-trade and continuous risk controls.

Initial values:

```text
Capital Limit: ₹1,000
Maximum Open Positions: 1
Planned Daily Loss Limit: ₹50
Planned Total Trial Loss Limit: ₹100
```

These are soft exposure limits and cannot guarantee maximum losses.

Additional protections:

- No leverage
- No derivatives
- No averaging down
- No martingale
- No unlimited retries
- No repeated orders after uncertain responses
- No trading on stale market data
- No orders during broker disconnection
- No trading when token authentication fails
- No trading when database persistence fails
- No trading after emergency stop
- No new trades when the loss budget is exhausted
- No automated order submission until broker compliance is verified

Implement position sizing using available capital, volatility, minimum tradable quantity and estimated costs.

Use broker-supported protective orders where appropriate.

## 10. INDstocks Integration

Implement an abstraction:

```csharp
public interface ITradingBroker
{
    Task<BrokerAccount> GetAccountAsync(
        CancellationToken cancellationToken);

    Task<MarketQuote> GetQuoteAsync(
        string symbol,
        CancellationToken cancellationToken);

    Task<IReadOnlyList<Candle>> GetCandlesAsync(
        string symbol,
        CancellationToken cancellationToken);

    Task<BrokerOrderResult> PlaceOrderAsync(
        TradeOrder order,
        CancellationToken cancellationToken);

    Task<BrokerOrderResult> CancelOrderAsync(
        string orderId,
        CancellationToken cancellationToken);

    Task<IReadOnlyList<BrokerPosition>> GetPositionsAsync(
        CancellationToken cancellationToken);
}
```

Expand the interface as needed without compromising Clean Architecture.

Create:

- `IndstocksBrokerAdapter`
- `PaperTradingBrokerAdapter`
- `BrokerReconciliationService`
- `MarketDataService`
- `OrderExecutionService`
- `TradingRiskService`

### Broker requirements

Implement:

- Access-token authentication
- Token expiry handling
- Profile and funds
- Instruments master
- Real-time quotes
- Historical OHLCV candles
- WebSocket market feed
- Order placement
- Order modification
- Order cancellation
- Order book
- Trade confirmations
- Holdings
- Positions
- Order-status reconciliation

Use exact documented request/response models.

Use decimal arithmetic for money and quantities where appropriate.

Implement reconnect logic, rate limiting, timeouts, backoff and structured errors.

**Critical:** On a timeout or unknown order response, query broker order history before attempting another order. Never blindly retry an order submission.

### Static IP requirement

Verify INDstocks static public IP whitelisting for direct API order placement.

The application must detect and report missing live-trading prerequisites.

Do not bypass broker security or exchange requirements.

If a static public IP is unavailable, retain paper and read-only functionality and disable Live trading.

## 11. Market News and Earnings

Create a **Market News** tab.

Display short, factual news pointers relevant to NSE/BSE stocks.

Fields:

- Headline
- Stock symbol
- Published time
- Source
- Category
- Positive/Negative/Neutral classification
- Original article URL
- Earnings date, where available
- Data freshness

Potential categories:

- Earnings
- Results announcements
- Corporate actions
- Regulatory announcements
- Bulk/block deals
- Sector news
- Major market events

Investigate legitimate free sources including:

- NSE corporate announcements
- BSE corporate announcements
- Official company investor relations
- RSS feeds from permitted publishers
- Free-tier licensed news APIs

Prefer official exchange disclosures for earnings and corporate announcements.

Do not scrape protected websites or violate provider terms.

Implement:

```csharp
public interface IMarketNewsProvider
{
    Task<IReadOnlyList<MarketNewsItem>>
        GetLatestNewsAsync(
            CancellationToken cancellationToken);
}
```

Add a provider abstraction so sources can be replaced later.

Cache news results to respect provider rate limits.

Do not describe a delayed news feed as real-time.

News sentiment must be treated as informational and not as a guaranteed predictive trading signal.

## 12. Additional Application Pages

Create these pages:

### Dashboard
Portfolio, P&L, market status and engine status.

### TradeList
Daily ranked 10-stock watchlist with technical signals.

### Market News
News, earnings and corporate announcements.

### Positions
Open positions, current value, P&L and holding duration.

### Orders
Order history, statuses, fills and rejection reasons.

### Trades
Completed trades and realized P&L.

### Strategy
Configurable screening and trading rules.

### Backtesting
Historical strategy evaluation and performance metrics.

### Settings
Environment details, broker connection, risk limits and trading configuration.

### System Logs
Errors, API failures, worker events and execution history.

### System Health
API connectivity, feed latency, database health, last successful sync and trading readiness.

## 13. Backtesting Engine

Implement a deterministic backtesting module.

Requirements:

- Historical OHLCV input
- Configurable entry/exit rules
- Realistic brokerage and statutory charges
- Slippage assumptions
- Liquidity checks
- No look-ahead bias
- Proper candle timestamp handling
- Corporate-action-adjusted data where available
- Overnight gaps
- Market holidays
- Position sizing
- Equity curve
- Drawdown calculation

Metrics:

- Total return
- Net return after charges
- Win rate
- Average win
- Average loss
- Profit factor
- Maximum drawdown
- Sharpe ratio, where statistically meaningful
- Number of trades
- Average holding duration

Never claim a backtest proves future profitability.

## 14. Paper Trading

Implement a fully functional paper-trading broker.

It must:

- Use live market data when available.
- Simulate order submission and execution.
- Apply realistic transaction costs.
- Simulate partial fills and slippage.
- Track cash and holdings.
- Persist simulated trades.
- Reconcile simulated orders.
- Respect all risk limits.
- Support Emergency Stop.

Paper trading must never send real orders.

Make Paper mode visually distinct from Live mode.

## 15. Database

Use EF Core migrations with SQLite.

Suggested entities:

```text
TradingSessions
TradeCandidates
DailyTradeLists
MarketCandles
MarketNews
EarningsEvents
TradingSignals
Orders
OrderExecutions
Positions
PortfolioSnapshots
StrategyConfigurations
RiskEvents
BrokerSyncEvents
SystemEvents
TradingControlState
```

Use appropriate indexes, foreign keys, UTC timestamps and concurrency protection.

Store exchange-local timestamps for display only.

Use UTC internally.

Never store raw access tokens or sensitive authentication secrets in the database.

## 16. Backend API

Suggested endpoints:

```text
GET  /api/dashboard
GET  /api/dashboard/pnl

GET  /api/tradelist/today
GET  /api/tradelist/history

GET  /api/news
GET  /api/earnings

GET  /api/positions
GET  /api/orders
GET  /api/trades

GET  /api/strategy
PUT  /api/strategy

GET  /api/system/health
GET  /api/system/status

POST /api/system/emergency-stop
POST /api/system/recover

GET  /api/settings
PUT  /api/settings
```

Add separate authenticated endpoints for Live activation and manual order actions if needed.

All state-changing endpoints require authorization and appropriate anti-forgery protection.

Do not expose broker credentials through API responses.

## 17. Windows Local Deployment

The application must run on a dedicated Windows laptop without Docker.

Provide PowerShell scripts for:

- Checking prerequisites
- Installing dependencies
- Restoring NuGet packages
- Installing npm dependencies
- Applying database migrations
- Starting development mode
- Starting production mode
- Stopping the application
- Running automated tests
- Checking application health

The setup should support:

```powershell
git clone <repository-url>
cd indstocks-trading-bot

.\scripts\setup-windows.ps1
.\scripts\run-dev.ps1
```

Production:

```powershell
.\scripts\run-prod.ps1
```

Provide exact working commands in README.

The application should open in the browser using a configured localhost address.

Support Windows Task Scheduler for optional automatic startup, but disable auto-trading by default after an unclean shutdown.

On restart:

1. Load persistent control state.
2. Check emergency-stop state.
3. Reconnect to broker.
4. Reconcile orders and holdings.
5. Verify risk limits.
6. Resume monitoring only when safe.

Do not submit new orders until reconciliation succeeds.

## 18. GitHub Requirements

Create a Git repository with:

- Clean folder structure
- README
- MIT license for original code, unless dependencies require a different compatible choice
- `.gitignore`
- `.env.example`
- Architecture documentation
- Windows setup guide
- API setup guide
- Risk management documentation
- Unit tests
- Integration tests
- GitHub Actions CI

GitHub Actions should:

- Restore .NET dependencies
- Build backend
- Run unit tests
- Install frontend dependencies
- Run frontend checks
- Build frontend

Never run live trading in CI.

Never commit tokens, credentials, local databases, personal trading data or production logs.

If GitHub authentication is available, create a **private repository** and push the code.

Otherwise, prepare a clean local repository and provide the exact commands to push it manually.

## 19. Testing Requirements

Test at least:

- Environment isolation
- Paper mode never calling live order endpoints
- Invalid/expired access tokens
- Static IP prerequisite
- Insufficient funds
- Capital-limit enforcement
- Duplicate order prevention
- Partial fills
- Broker API timeouts
- Unknown order outcomes
- WebSocket disconnection
- Stale market data
- Market holidays
- Incorrect instrument IDs
- Stop-loss execution
- Overnight position handling
- Emergency Stop persistence
- Emergency Stop during an in-flight order
- Restart recovery
- Portfolio reconciliation
- Brokerage and tax calculations
- Net P&L calculations

Use mocks for broker integrations.

Never use real-money orders during automated tests.

## 20. Execution Plan for Codex

Implement in phases.

### Phase 1: Foundation

- Create React and .NET solution.
- Implement Clean Architecture.
- Configure environment isolation.
- Create SQLite database.
- Add logging, validation and health checks.
- Build dashboard shell.

### Phase 2: Broker integration

- Read official INDstocks documentation.
- Implement authenticated read-only API.
- Implement market quotes and candles.
- Implement WebSocket subscriptions.
- Implement holdings and portfolio retrieval.
- Add connection-status dashboard.

### Phase 3: Trading intelligence

- Implement daily TradeList.
- Implement technical indicators.
- Implement strategy rules.
- Implement market news and earnings.
- Implement historical data storage.

### Phase 4: Paper trading

- Implement paper broker.
- Implement position management.
- Implement risk engine.
- Implement P&L calculations.
- Implement backtesting.
- Implement Emergency Stop.

### Phase 5: Live-trading readiness

- Implement real order adapter.
- Verify regulatory and broker prerequisites.
- Implement broker reconciliation.
- Implement live-order safeguards.
- Add explicit Live activation.
- Keep Live disabled by default.

### Phase 6: Windows deployment

- Implement PowerShell scripts.
- Run automated tests.
- Verify local startup.
- Prepare documentation.
- Push to private GitHub repository if authorized.

## 21. Definition of Done

The project is complete when:

1. React frontend builds and runs.
2. .NET backend builds and runs.
3. SQLite migrations work.
4. Development and Production configurations are isolated.
5. INDstocks read-only API connectivity is functional with a valid token.
6. Dashboard displays accurate portfolio information.
7. TradeList generates up to 10 qualified candidates.
8. Market News displays sourced information.
9. Paper-trading engine operates automatically.
10. Emergency Stop works and persists.
11. Trading safeguards pass automated tests.
12. Live-trading integration is implemented but disabled until all prerequisites are verified.
13. Windows installation scripts work.
14. GitHub repository is clean and documented.
15. README provides exact clone, configuration, start, stop and troubleshooting steps.

## 22. Implementation Instructions

Proceed with implementation using the repository and tools available to you.

Do not stop after writing an architectural proposal.

Create working code, run builds, fix compilation errors and execute tests.

Use established engineering practices. Avoid unnecessary frameworks, dependencies and complexity.

Do not repeatedly ask questions when a safe default is available.

Document any unsupported broker feature rather than inventing functionality.

Do not run real-money trades, activate Live mode, or submit live orders without separate explicit user authorization.

The user will refine the UI design after the initial functional implementation.

At completion, report:

- Repository URL or local repository location
- Implemented features
- Build and test results
- Remaining limitations
- INDstocks integration status
- Windows setup commands
- Steps required before enabling Live trading

**Final objective:** Deliver a functional, secure, extensible automated trading application that runs locally on Windows, supports INDstocks Flash API, provides real-time monitoring, and allows controlled progression from paper trading to live trading.
