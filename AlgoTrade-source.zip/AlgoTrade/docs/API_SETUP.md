# INDstocks integration

Authoritative sources, downloaded and inspected before implementing the adapter on 2026-11-16:

- https://api-docs.indstocks.com/llms/
- https://api-docs.indstocks.com/llms-full.txt — saved as `broker/indstocks-api-docs.md`
- https://api-docs.indstocks.com/openapi-spec.yaml — saved as `broker/openapi-spec.yaml`
- https://api-docs.indstocks.com/Users/
- https://api-docs.indstocks.com/MarketQuote/
- https://api-docs.indstocks.com/Websockets/

Base URL: `https://api.indstocks.com`. HTTP authorization header uses the raw access token, **without** a `Bearer` prefix. Generate it in the official INDstocks account flow. Do not supply account MPIN, OTP, browser cookies or email passwords to this app. TOTP token generation is marked provisional in the downloaded reference and is not implemented here. Renew expired tokens manually and restart the relevant API environment. No refresh endpoint has been invented.

The backend file `api/.env.development` (or `.production`) accepts `INDSTOCKS_ACCESS_TOKEN`. Optional DEV user-secrets instructions are in README. Check Settings → Test broker connection. Missing/invalid tokens produce actionable errors; the paper ledger remains independent. Profile data is not written to logs or database.

## Implemented read-only paths

| Local authenticated API | Broker GET |
|---|---|
| `/api/broker/profile` | `/user/profile` |
| `/api/broker/funds` | `/funds` |
| `/api/broker/holdings` | `/portfolio/holdings` |
| `/api/broker/positions` | `/portfolio/positions` |
| `/api/broker/quotes?scripCodes=NSE_3045` | `/market/quotes/full?scrip-codes=NSE_3045` |
| `/api/broker/candles?scripCode=NSE_3045&start=<epoch-ms>&end=<epoch-ms>` | `/market/historical/5minute` with documented query names |
| `/api/broker/instruments` | `/market/instruments?source=equity` |

Responses retain documented raw JSON/CSV schemas. They are not merged into the simulated paper portfolio. The historical query accepts one equity instrument and up to 30 days. Broker candle `ts` values are candle-open epoch **seconds**, although request boundaries are epoch **milliseconds**. Convert input to UTC correctly before using the backtester.

The adapter permits only validated NSE/BSE numeric REST codes (`NSE_3045`), with at most 20 codes per quote request. Resolve IDs from the official instrument master; symbols alone are not security IDs. It serializes requests to at most one per second, sets a 15-second timeout, disables redirects and does not blindly retry. Invalid auth, rate limits and other errors are reported without returning broker error bodies that could contain sensitive information. This conservative limiter is not a substitute for checking the broker's current category-specific quota table.

API authentication uses local HttpOnly SameSite=Strict session cookies. All POST API requests, including login, require the token from GET `/api/auth/csrf` in `X-CSRF-TOKEN`. Fetch another CSRF token after login because identity changed. Login is limited to 5 attempts per minute; broker API requests to 15 per minute. Use the UI's same-origin proxy; cross-origin credential access is not enabled. OpenAPI JSON is available after login at `/openapi/v1.json` (no Swagger UI bundled).

## Missing broker functionality

Price/order WebSocket streaming, live orders, modifications/cancellations, live order-book/trade reconciliation and automatic account synchronization are not implemented. `PlaceOrderAsync` always throws before network access. No arbitrary URL forwarding exists, and broker authorization is never passed to React.

The specific documented price endpoint is `wss://ws-prices.indstocks.com/api/v1/ws/prices`; the order feed is `wss://ws-order-updates.indstocks.com/api/v1/ws/trades`. Some introductory export snippets use a different generic WebSocket URL. A future adapter must use the specific WebSocket reference and verify authentication, nested/string-encoded envelopes and timestamps before enabling trading. REST uses underscore security codes; WebSocket subscriptions use colon-separated tokens.

The official user documentation says static public IPv4 whitelisting is required for placement, modification **and cancellation**, while quote/portfolio reads do not require it. Whitelist edits have a calendar-week restriction. Confirm current broker/exchange requirements directly. No static-IP auto-detection/verification is implemented; Live is disabled regardless of supplied token or algo ID. No broker token has been provided for an account test, so this release cannot claim live-account connectivity validation.
