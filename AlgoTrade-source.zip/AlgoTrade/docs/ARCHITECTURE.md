# Architecture

`ui` is React/TypeScript/Vite with Tailwind, a local shadcn-style Button component (Radix Slot/CVA), Lucide icons and ECharts for backtest equity. It knows only `/api` and `/hubs/dashboard`. The development Vite proxy points to API port 5100. Production port 5101 serves `ui/dist` directly. No broker secrets are compiled into JavaScript.

Dependency direction:

```text
Domain <- Application <- Infrastructure
              ^                 ^
            Worker              |
              ^                 |
              +------ API ------+
```

Domain defines orders, positions, trades, ledger/control state and OHLCV records. Application defines contracts, a risk evaluator, cost assumptions and deterministic backtesting. Infrastructure implements EF Core SQLite and a paper ledger, configuration loading, and read-only INDstocks REST. API owns HTTP authorization, anti-forgery, rate limiting and SignalR. The hosted Worker only completes pending simulated partial fills, never broker orders or strategy entries.

One API process owns an environment database via an exclusive OS file lock. All state-changing paper operations use the same singleton semaphore and a database transaction. Emergency stop and worker fills share that gate. An order already holding the gate can complete before stop acquires it; after stop returns, pending remainders are cancelled and later fills are denied. This does not claim a broker-side cancellation: there is no live order adapter.

An idempotent client UUID has a unique database index. Replaying it returns the original outcome. Cash is debited at fills; unfilled BUY commitments are reserved separately and removed from available cash. Account equity equals remaining cash plus marked holdings, not invested capital plus account cash plus pending reserves. Buy costs enter cost basis; exit proceeds minus allocated basis and exit costs determine realized P&L.

SQLite decimal columns preserve decimal values as TEXT; calculations intentionally materialize monetary rows and perform arithmetic in .NET decimal. Tables: Accounts, ControlStates, Orders, Positions, Trades, Events and EF migration history. Unique instrument/client-ID indexes and trade-to-order foreign keys are committed in migrations. Remaining handoff data tables are not implemented. UI history endpoints currently bound results to the most recent 200 records; the database keeps the ledger.

Timestamps are UTC, converted to Asia/Kolkata for display/session loss-budget attribution. SQLite's unspecified DateTime kind is treated as UTC. Portfolio marks are simulated execution prices, not live prices. Today's P&L is realized-only until reliable previous-close marks are implemented. This is labelled in the UI/API status.

Every restart preserves EMERGENCY_STOPPED; a running session becomes RECOVERY_REQUIRED. Recovery cancels pending simulated remainders, checks the local cash/position ledger, and requires START PAPER. It does not imply reconciliation with a real brokerage account. Database failure prevents a successful order response. If the DB is inaccessible, stop cannot claim its state was persisted; stop the process and inspect storage before recovery.

Auth: an operator password from backend-only local config is compared in fixed time after SHA-256 hashing (the configured plaintext itself is not persisted in SQLite). ASP.NET data-protection cookies are HttpOnly, SameSite Strict, nonpersistent and expire after eight hours. CSRF is validated on every POST API path, including login. The app is HTTP loopback only, with host checks against DNS rebinding. It is not a multiuser or remotely hosted authentication service. Do not expose it with port forwarding. Use Windows protection for your config and ASP.NET data-protection key directory.
