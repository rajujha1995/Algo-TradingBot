# Windows setup

Use `C:\RJ\AlgoTrade` as the root. `ui` and `api` are separate projects; scripts always resolve the root from their own directory, not a hardcoded username/path. Paths with spaces are supported by the production DLL launch argument.

1. Install .NET 10 SDK and Node 24 LTS, or run `scripts/setup-windows.ps1 -InstallPrerequisites` using winget. Git is needed only to clone. No Docker or database installation is needed.
2. Run setup from the README. It creates local `.env.development`/`.env.production` files in both projects without replacing existing files. API files get separate random passwords.
3. Find `LOCAL_ADMIN_PASSWORD` in `api/.env.development`. Optionally add a broker token in that API file. Do not put secrets in UI files.
4. Run `scripts/run-dev.ps1`. Use `http://127.0.0.1:5173`. Sign in and manually confirm START PAPER.
5. Use the red emergency stop before stopping a session. `scripts/stop-bot.ps1` terminates only managed process trees.
6. For PROD, run `scripts/run-prod.ps1`, use `http://127.0.0.1:5101`, and sign in with the production password. PROD remains Paper.

Setup requires internet access to NuGet, npm and (when installing prerequisites) Microsoft's winget sources. Corporate proxies may need OS/.NET/npm proxy configuration; never disable TLS verification. If installation adds PATH entries, reopen the terminal.

Migrations run automatically at API initialization and through `dotnet run --no-launch-profile --project api/TradingBot.Api -- --migrate-only`. Use the desired `ASPNETCORE_ENVIRONMENT` first. `dotnet ef database update` is **not** the deployment command: the design-time context deliberately points to an unused design-only file. Generate migrations with `dotnet ef migrations add <Name> --project api/TradingBot.Infrastructure` and commit them.

Do not run as Administrator for routine use. Keep the project under your own Windows account and protect its local secret files. API and UI listen on loopback. Task Scheduler logon registration is optional and does not resume a running session without recovery. Windows Task Scheduler/winget behavior must still be verified on the target Windows laptop; Linux validation cannot establish that those OS integrations work.
