The backtest-demo.json file contains SYNTHETIC prices for upload testing. It is not exchange data or evidence of profitable trading.
