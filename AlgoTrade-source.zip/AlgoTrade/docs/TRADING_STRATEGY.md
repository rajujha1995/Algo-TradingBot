# Strategy and backtesting

Automatic screening, daily TradeList composition (4 large/3 mid/3 small), pre-open auction analysis, news sentiment and continuous entry/exit rules from the handoff remain unimplemented. The UI does not manufacture picks, classification, headlines or live quotes. Do not use a token configuration as evidence of trading readiness.

The implemented research backtester accepts 7–10,000 adjusted, chronological UTC OHLCV candles. Data should already exclude exchange-closed periods and reflect corporate actions; there is no bundled holiday/calendar service or adjustment engine. Decisions use the preceding completed candle versus a trailing five-candle SMA. Entries/exits fill at the following open with slippage/fees. Entries require volume >=1,000 and cap quantity at 1% of current candle volume. Historical volume at fill time is an optimistic liquidity assumption; model it more conservatively before treating results as predictive. The final existing position is closed at the final candle open to finish the run. It never fills a signal at the same close used to generate it.

Returned metrics: initial/final equity, net return, maximum drawdown, completed trade count, win rate, charges and equity curve. Sharpe, profit factor, overnight risk rules and full handoff metrics remain unavailable. No parameter optimization is implemented.

Input JSON array (use at least seven candles):

```json
[
  {"timestampUtc":"2026-01-05T03:45:00Z","open":100,"high":102,"low":99,"close":101,"volume":10000},
  {"timestampUtc":"2026-01-05T03:50:00Z","open":101,"high":103,"low":100,"close":102,"volume":12000}
]
```

A complete synthetic example is in `docs/examples/backtest-demo.json` and is labelled synthetic. Upload it on Backtesting. The file input limit is 2 MB; API validation caps the number of candles. Broker OHLCV responses must be explicitly converted: `ts` is epoch seconds at candle open, `{o,h,l,c,v}` map to the above fields. Never infer an auction price from an ordinary last traded quote.
