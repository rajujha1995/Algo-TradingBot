# Validation record

Validated on 2026-11-16 in the managed Linux workspace with .NET SDK 10.0.404, Node 24.22.1, npm 11.9.0 and PowerShell 7.7.0. This is not a claim of target-Windows certification.

| Check | Result |
|---|---|
| NuGet locked restore and backend Debug/Release builds | Passed; no compilation warnings/errors. |
| xUnit unit tests | 23 passed: config isolation/Live rejection, risk, costs, broker auth/errors/timeouts/read-only safety, deterministic backtest and no-lookahead check. |
| xUnit SQLite integration tests | 15 passed: migrations, initial stop, idempotency and changed-price rejection, buy/sell accounting, partial fills/reserves/negative-cash prevention, stop persistence and in-flight serialization, restart recovery, capital/loss limits, no shorting and storage failure. |
| TypeScript check / production Vite build | Passed. |
| Vitest | 2 passed. |
| Playwright Chromium | 3 passed: authenticated paper flow and stop persistence, unauthorized/CSRF checks and credential-free settings, documented backtest upload/results. |
| EF model-vs-committed-migration check | Passed; no pending model changes. |
| NuGet package vulnerability scan, including transitive dependencies | No known vulnerable packages reported by configured source at scan time. |
| npm audit | 0 vulnerabilities reported at scan time. |
| PowerShell parsing | All scripts parsed successfully. |
| Source-only fresh setup copy | Passed from `/workspace/scratch/AlgoTrade fresh clone`: npm ci, locked NuGet restore, UI/API build, generation of separate DEV/PROD credential files, both SQLite migrations. |
| PowerShell DEV start/test/stop | Passed using the documented scripts on Linux-compatible branches, with three browser tests against the fresh copy. |
| PowerShell PROD publish/start/health/stop | Passed from the path with spaces; root served the built UI and health returned Production/PAPER. |
| Secrets/artifact exclusion | Tracked files checked for generated operator passwords; environment files, DBs, logs, build output and dependencies excluded from source ZIP. |
| Manual UI inspection | Desktop dashboard screenshot captured and inspected; screenshot contains synthetic paper data only. |

Non-blocking tooling diagnostics: SignalR package PURE-comment annotations are removed by Rollup; the UI bundle exceeds Vite's 500 kB advisory because of charting; VSTest emits an artifact-directory diagnostic while all tests pass. These do not prevent setup, build or test execution.

Not verified: a real INDstocks account/token, real broker payload behavior, Windows winget installation/elevation, Windows-specific process-tree termination, Task Scheduler registration, or the included hosted GitHub Actions workflow. All broker tests use mocks. No live order endpoint is enabled or called. Read IMPLEMENTATION_STATUS.md for unfinished trading features; installing dependencies does not implement them.
