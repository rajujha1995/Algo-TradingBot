# Implementation status and acceptance checklist

This repository is the first runnable foundation from the handoff, not all six completed phases. The original requirements are preserved in HANDOFF.md. User-requested folder names are `ui/` and `api/` instead of the original frontend/backend names.

| Requirement | Status / practical limit |
|---|---|
| React/TS/Vite, Tailwind, editable components, ECharts | Implemented; chart currently shows backtest equity only. |
| .NET 10 Clean Architecture, SignalR, Serilog | Implemented. Worker hosted inside API; structured logs to console/script files. |
| SQLite migrations and environment isolation | Implemented for current ledger/control/events. Remaining screening/news/session tables unavailable. |
| Startup validation and credentials | Implemented; loopback, strict same-site auth cookie and CSRF; local plaintext config supported, protected-secret retrieval not bundled. |
| Portfolio dashboard | Paper cash/basis/current marks, net P&L, charges and counts; marks are simulated execution prices, day P&L realized-only. No broker portfolio merge. |
| Emergency Stop | Persistent/idempotent local paper stop, shared order gate, cancels pending remainders, retains holdings, recovery confirmation. No broker cancellation claim. |
| Paper orders | Manual DEMO orders only; adverse slippage, partial fills, persistence, cash/commitments, loss/position/capital checks. |
| INDstocks REST | Documented read-only profile/funds/holdings/positions/quotes/candles/instrument CSV. Mock-tested; no account token supplied for live validation. |
| WebSocket market/order feeds | Not implemented. No automatic reconnect/subscription/reconciliation. |
| TradeList and technical screening | Not implemented. No maintained classifications, approved universe or exchange calendar supplied. UI shows unavailable. |
| News and earnings | Not implemented. No licensed provider integration. UI shows unavailable. |
| Automatic trading engine | Not implemented; AUTO_TRADING_ENABLED=true fails startup. Worker completes simulated remainders only. |
| Continuous stops / overnight policy | Not implemented. No automated exits/liquidation. Manual simulated SELL only. |
| Backtesting | Deterministic SMA, next-open fills, volume assumption, fees/slippage, core metrics/equity curve. No corporate action or market-calendar engine. |
| Charge breakdown | Aggregate indicative cost estimate only; actual broker tariff and detailed statutory itemization pending. |
| Live placement/modify/cancel | Not implemented; adapter rejects before network. |
| Unknown live order outcomes | No live calls possible; real order history/reconciliation implementation pending. Manual paper UUID idempotency exists. |
| Static IP/compliance readiness | Documented, not programmatically verified. All Live activation blocked. |
| Local deployment | Windows setup/start/stop/test/health/task registration scripts included. PowerShell parsing and Linux-compatible paths tested; Windows OS integration not yet tested on a laptop. |
| Unit/integration/browser tests | Current ledger/risk/auth/browser scope; exact results in VALIDATION.md. No real-money calls. |
| GitHub | Local Git repository prepared; push deferred by user. CI workflow included, not claimed as a completed hosted run. |

## Work required to complete the original handoff

1. Verify read-only broker responses using a customer-authorized token; normalize documented models without exposing secrets; implement connection/freshness state.
2. Implement authenticated price/order WebSocket clients with bounded reconnect/backoff, stale-feed blocking and symbol/ID verification. Verify every lifecycle message against the official specific reference.
3. Add maintained exchange sessions/holiday data, authoritative market-cap classification and permitted news/earnings providers; persist daily TradeList and indicator history. Do not guess unavailable auction data.
4. Implement automatic paper entry/exit orchestration using fresh verified feeds; protective stops, loss-budget monitoring, scheduled reviews and overnight/holding limits; expand risk/failure tests.
5. Implement a verified live execution adapter, durable submission intents, client/broker correlation, order-book reconciliation after unknown outcomes, partial fills, cancel/modify handling and restart recovery. Never blindly retry order submissions.
6. Validate costs and taxes against current broker/exchange tariffs; provide itemized charges and full portfolio reconciliation/day P&L.
7. Add backend-only explicit Live authorization and prerequisite verification including whitelisted static public IPv4, account permissions and compliance. Obtain separate explicit user approval before any real-money order.
8. Run all acceptance scenarios from the handoff, target-Windows setup/stop/Task Scheduler testing and a monitored paper trial before considering live activation.

These are code/data/compliance dependencies, not issues that can all be resolved by installing a package or replacing a token. Nothing here claims trading profitability or completion of the live system.
