Official INDstocks reference exports retrieved 2026-11-16. Publisher terms apply; these documents are not relicensed under MIT.

- indstocks-api-docs.md: SHA256 `6787f3833fbb32e045db2ad0b5455e3d12ff483d851a545aa5a37c017a540dfb`
- openapi-spec.yaml: SHA256 `10e61128dbc58133b6c1f4cd967805951b7f3fd3cdd7741992351496f747ca02`
