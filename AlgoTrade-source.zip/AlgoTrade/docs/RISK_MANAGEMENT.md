# Risk management

Paper starts stopped. Production is also Paper. LIVE and AUTO_TRADING_ENABLED=true are rejected at startup. No derivatives, short selling, leverage, averaging down or martingale order flow is exposed. The current release accepts manual orders only for synthetic DEMO. It cannot automatically trade NSE/BSE shares.

BUY checks include state immediately before the transaction, one open position, no pending BUY, available cash after commitments, cost-inclusive exposure <= ₹1,000 and realized daily/total-trial loss budgets. Configured default budgets: ₹50 daily and ₹100 total. Total check also includes the current simulated unrealized loss. As paper marks are execution prices, this is not continuous real-market risk monitoring. SELL requires sufficient holdings and proceeds above estimated exit fees. Protective stops and overnight holding enforcement are not implemented.

Emergency stop persists a centralized state and cancels paper unfilled remainders. Holdings remain visible. Restart recovery is manual. Order IDs are client-generated UUIDs with a unique database index; uncertain network outcomes must be checked using the same ID/order history, never retried with a new ID. The UI retains its request ID after an error; avoid changing/reloading a pending form until checking Orders. Closed positions can be replaced only within remaining capital/loss limits.

## Cost assumptions, not a broker contract note

Indicative **NSE delivery**, applied per fill with decimal rounding:

- Brokerage: ₹0 assumption (verify current tariff).
- STT: 0.1% of turnover on BUY and SELL.
- Exchange transaction charge: 0.00297% of turnover.
- SEBI turnover charge: 0.0001%.
- GST: 18% of exchange + SEBI charges under this simplified model.
- Stamp duty: 0.015% on BUY.
- DP charge: estimated ₹15.93 once per SELL order (tax-inclusive assumption).
- Slippage: configurable 5 basis points by default in the adverse direction.

The return value is an aggregate fee estimate. The dashboard does not yet itemize statutory charges/taxes/brokerage separately. Real contract-note rounding, per-ISIN/day DP charging, tariff changes, BSE differences, minimums and tax treatment require a verified replacement cost model before real-market use. Partial fills may accumulate an extra paisa of rounding. Estimates are intentionally not represented as actual broker charges.

Backtesting applies the same assumptions, caps participation at 1% of candle volume for entries, and supports one long position. Its estimated P&L cannot guarantee maximum loss or future profitability. The default ₹1,000/five-session trial is a research assumption. No forced daily trade, minimum return or guaranteed outcome is implied.
