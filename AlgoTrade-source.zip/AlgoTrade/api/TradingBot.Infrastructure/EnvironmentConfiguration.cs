using TradingBot.Application;
namespace TradingBot.Infrastructure;

public static class EnvironmentConfiguration
{
  public static TradingOptions Load(string root, string environment, Func<string, string?>? secret = null)
  {
    if (environment is not ("Development" or "Production")) throw new InvalidOperationException("ASPNETCORE_ENVIRONMENT must be Development or Production.");
    var path = Path.Combine(root, "api", environment == "Development" ? ".env.development" : ".env.production");
    var values = new Dictionary<string, string>(StringComparer.Ordinal);
    if (File.Exists(path)) foreach (var line in File.ReadAllLines(path))
    {
      var trimmed = line.Trim(); if (trimmed.Length == 0 || trimmed.StartsWith('#')) continue;
      var parts = trimmed.Split('=', 2); if (parts.Length != 2) throw new InvalidOperationException("Invalid environment-file line.");
      values.Add(parts[0].Trim(), parts[1].Trim());
    }
    string Get(string key, string fallback = "") => secret?.Invoke(key) ?? System.Environment.GetEnvironmentVariable(key) ?? values.GetValueOrDefault(key, fallback);
    if (Get("APP_ENV", environment) != environment) throw new InvalidOperationException("APP_ENV must match ASPNETCORE_ENVIRONMENT.");
    if (Get("AUTO_TRADING_ENABLED", "false") != "false") throw new InvalidOperationException("Automatic strategy execution is unavailable; keep AUTO_TRADING_ENABLED=false.");
    if (Get("INDSTOCKS_BASE_URL", "https://api.indstocks.com") != "https://api.indstocks.com") throw new InvalidOperationException("Only the official INDstocks API base URL is allowed.");
    var options = new TradingOptions
    {
      Root = root,
      Environment = environment,
      TradingMode = Get("TRADING_MODE", "PAPER"),
      LocalPassword = Get("LOCAL_ADMIN_PASSWORD"),
      AccessToken = Get("INDSTOCKS_ACCESS_TOKEN"),
      DatabasePath = Path.GetFullPath(Get("DATABASE_PATH", environment == "Development" ? "data/trading-dev.db" : "data/trading-prod.db"), Path.Combine(root, "api")),
      CapitalLimit = TradingOptions.ParseDecimal(Get("TRADING_CAPITAL_LIMIT", "1000")),
      DailyLossLimit = TradingOptions.ParseDecimal(Get("MAX_DAILY_PLANNED_LOSS", "50")),
      TotalLossLimit = TradingOptions.ParseDecimal(Get("MAX_TOTAL_PLANNED_LOSS", "100")),
      MaxOpenPositions = int.Parse(Get("MAX_OPEN_POSITIONS", "1")),
      SlippageBps = TradingOptions.ParseDecimal(Get("PAPER_SLIPPAGE_BPS", "5"))
    };
    options.Validate(); return options;
  }
  public static string FindRoot()
  {
    var configured = System.Environment.GetEnvironmentVariable("TRADINGBOT_ROOT"); if (configured != null) return Path.GetFullPath(configured);
    for (var d = new DirectoryInfo(Directory.GetCurrentDirectory()); d != null; d = d.Parent) if (Directory.Exists(Path.Combine(d.FullName, "api")) && Directory.Exists(Path.Combine(d.FullName, "ui"))) return d.FullName;
    throw new InvalidOperationException("Run from repository root or set TRADINGBOT_ROOT.");
  }
}
