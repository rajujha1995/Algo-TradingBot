[CmdletBinding()]
param([switch]$NoBrowser)
. "$PSScriptRoot/common.ps1"
Set-Location $script:RepoRoot
Assert-Prerequisites
Set-AppEnvironment 'Development'
Assert-PortFree 5100
Assert-PortFree 5173
if (-not (Test-Path api/.env.development)) { throw 'Run scripts/setup-windows.ps1 first.' }
Invoke-Checked 'dotnet' @('build','api/TradingBot.sln','--no-restore')
try {
 Start-ManagedProcess 'api-dev' 'dotnet' 'run --no-build --no-launch-profile --project api/TradingBot.Api' $script:RepoRoot
 Wait-AppHealth 5100
 if ($env:OS -eq 'Windows_NT') { Start-ManagedProcess 'frontend-dev' 'cmd.exe' '/d /s /c "npm run dev"' (Join-Path $script:RepoRoot 'ui') }
 else { Start-ManagedProcess 'frontend-dev' 'npm' 'run dev' (Join-Path $script:RepoRoot 'ui') }
 $deadline=(Get-Date).AddSeconds(30)
 do {
  try { $response=Invoke-WebRequest 'http://127.0.0.1:5173' -UseBasicParsing -TimeoutSec 2; if($response.StatusCode -eq 200){break} } catch { }
  if((Get-Date) -ge $deadline){throw 'Frontend failed to start. Inspect .runtime/frontend-dev.*.log.'}
  Start-Sleep -Milliseconds 500
 } while ($true)
 if (-not $NoBrowser) { Start-Process 'http://127.0.0.1:5173' }
 Write-Host 'DEV: http://127.0.0.1:5173. Stop with .\scripts\stop-bot.ps1 -Environment Development.'
} catch { Stop-ManagedProcess 'frontend-dev'; Stop-ManagedProcess 'api-dev'; throw }
